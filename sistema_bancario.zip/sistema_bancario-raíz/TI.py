import sys
class Conta:
    def __init__(self, numero, agencia, saldo = 0,cliente= None):
        self.numero = numero
        self.agencia = agencia
        self.saldo = saldo
        self.cliente = cliente

    def getnumero(self):
        return self.numero

    def getagencia(self):
        return self.agencia

    def getsaldo(self):
        return self.saldo
    def debitar(self, valor):
        valor = int(input("valor debitado:"))
        self.saldo -= valor

    def creditar(self, valor):
        self.saldo += valor
    def tranferir(self, valor, conta):
        self.saldo -= valor
        conta.saldo += valor


class Poupanca(Conta):
    def __init__(self, numero, agencia, saldo, cliente, taxa_juros, data):
        Conta.__init__(self, numero, agencia, saldo, cliente)
        self.juros = taxa_juros
        self.data = data
    def getjuros(self):
        return self.juros

    def setjuros(self, taxa_juros):
        self.juros = taxa_juros
    def getdata(self):
        return self.data

    def setdata(self, data):
        self.data = data
class Cliente():
    def __init__(self, nome, CPF):
        self.nome = nome
        self.CPF = CPF
    def getnome(self):
        return self.nome
    def getCPF(self):
        return self.CPF
class Banco:
    def __init__(self):
        self.contas = []
        self.clientes = []

    def cadastrar_conta(self, numero, agencia, saldo):
        conta = Conta(numero,agencia, 0, None)
        self.contas.append(conta)
        print("Operação Realizada com sucesso")
    def cadastrar_cliente(self, nome, CPF):
        cliente = Cliente(nome,CPF)
        self.clientes.append(cliente)
    def imprimir_contas(self):
        print(self.contas)
    def impirimir_clientes(self):
        print(self.clientes)
    def pesquisarConta(self, numConta):
        conta = None
        for x in self.contas:
            if x.numero == numConta:
                return x
sys.exit(0)
def debitar(self, numConta, valor):
    conta = pesquisarConta(numConta)
    if valor < conta.saldo:
        print("Operação Realizada com sucesso")
        conta.saldo -= valor
    else:
        print("Saldo inválido")

def tranferir(self, valor, numContaDestino, numContaRemetente):
    contaDestino = pesquisarConta(numContaDestino)
    contaRemetente = pesquisarConta(numContaRemetente)
    contaRemetente.saldo -= valor
    contaDestino.saldo += valor
def getsaldo(self, numConta):
    conta = pesquisarConta(numConta)
    return conta.saldo

def menu(self):
    while True:
        print("0-Sair" + "\n" + "1-Cadastrar conta" + "\n" + "2-cadastrar cliente" + "\n" + "3-impirimir contas" + "\n" + "4-impirimir clientes" + "\n" + "5- creditar conta" + "\n" + "6- debitar conta" + "\n"
        + "7 -transferir"+ "\n")
        opcao = int(input("digite sua opção:"))

        if opcao == 0:
            break
        elif opcao == 1:
            numero = input("insira o numero da conta:")
            agencia = input("insira a agencia")
            self.cadastrar_conta(numero, agencia, None)

        elif opcao == 2:
            nome = input("insira seu nome:")
            CPF = input("insira seu CPF:")
            self.cadastrar_cliente(nome, CPF)

        elif opcao == 3:
            self.imprimir_contas()
        elif opcao == 4:
            self.impirimir_clientes()

        elif opcao == 5:
            numConta = int(input("qual o numero da conta?:"))
            valor = int(input("qual valor?:"))
            creditar(numConta, valor)
        elif opcao == 6:
            numConta = int(input("qual o numero da conta?:"))
            valor = int(input("qual valor?"))
            debitar(numConta, valor)
        elif opcao == 7:
            numContaDestino = input("Qual o numero da conta destino;")
            numContaRemetente = input("Qual o numero da conta remetente;")
            valor = input("Valor")
            tranferir(valor, numContaDestino, numContaRemetente)

banco1 = Banco()
banco1.menu()







