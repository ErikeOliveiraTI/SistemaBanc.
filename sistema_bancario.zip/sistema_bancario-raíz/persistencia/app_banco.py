from banco import Banco
banco = Banco()
opcao = ''
while opcao != 'x':
    opcao = banco.menu()