from conta import Conta
c1 = Conta('123',100)
c2 = Conta('123',100)
print(c1==c2)

